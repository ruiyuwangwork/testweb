Data Scientist
==============

I am also interested in machine learning and I have learnt many machine learning techniques

I am looking forward to introduce machine learning to my research